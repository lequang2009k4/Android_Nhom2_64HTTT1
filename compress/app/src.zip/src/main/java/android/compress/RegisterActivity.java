package android.compress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class RegisterActivity extends AppCompatActivity {

    private static final String TAG = "RegisterActivity";

    private EditText usernameEditText;
    private EditText phoneEditText;
    private TextInputEditText passwordEditText;
    private Button registerButton;
    private TextView loginTextView;

    private DatabaseReference mDatabase;

    // Tên miền ảo của bạn để tạo email Firebase
    // Đảm bảo tên miền này là duy nhất cho ứng dụng của bạn để tránh xung đột
    private static final String FIREBASE_EMAIL_DOMAIN = "@yourappdomain.com"; // THAY ĐỔI ĐIỀU NÀY!

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mDatabase = FirebaseDatabase.getInstance().getReference(); // Khởi tạo Realtime Database

        usernameEditText = findViewById(R.id.usernameRegisterEditText);
        phoneEditText = findViewById(R.id.phoneRegisterEditText);
        passwordEditText = findViewById(R.id.passwordRegisterEditText);
        registerButton = findViewById(R.id.registerButton);
        loginTextView = findViewById(R.id.loginTextView);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String phone = phoneEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                String role = "user"; // Mặc định role là "user" khi đăng ký. Bạn có thể thay đổi.

                // Bước 1: Kiểm tra các trường nhập liệu
                if (username.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Vui lòng điền đầy đủ thông tin.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (username.contains(" ") || username.contains("@") || username.contains(".")) {
                    Toast.makeText(RegisterActivity.this, "Tên đăng nhập không hợp lệ (không chứa khoảng trắng, '@', '.').", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 6) { // Firebase Email/Password Auth yêu cầu mật khẩu tối thiểu 6 ký tự
                    Toast.makeText(RegisterActivity.this, "Mật khẩu phải có ít nhất 6 ký tự.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Thêm tiền tố quốc gia cho số điện thoại nếu chưa có
                if (!phone.startsWith("+")) {
                    phone = "+84" + phone; // THAY ĐỔI "+84" NẾU BẠN DÙNG MÃ QUỐC GIA KHÁC
                }

                // Bước 2: Kiểm tra xem username đã tồn tại chưa trong Realtime Database
                checkIfUsernameExists(username, phone, password, role);
            }
        });

        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Đóng RegisterActivity nếu chuyển sang Login
            }
        });
    }

    private void checkIfUsernameExists(String username, String phone, String password, String role) {
        Query usernameQuery = mDatabase.child("users").orderByChild("username").equalTo(username);
        usernameQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Username đã tồn tại
                    Toast.makeText(RegisterActivity.this, "Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.", Toast.LENGTH_LONG).show();
                } else {
                    // Username chưa tồn tại, chuẩn bị chuyển sang OtpVerificationActivity
                    String firebaseEmail = username + FIREBASE_EMAIL_DOMAIN; // Tạo email ảo

                    Intent intent = new Intent(RegisterActivity.this, OtpVerificationActivity.class);
                    // Truyền tất cả thông tin đăng ký sang OtpVerificationActivity
                    intent.putExtra("username", username);
                    intent.putExtra("password", password);
                    intent.putExtra("phone_number", phone);
                    intent.putExtra("role", role);
                    intent.putExtra("firebase_email", firebaseEmail);
                    startActivity(intent);
                    finish(); // Đóng RegisterActivity để tránh quay lại khi nhấn Back
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RegisterActivity.this, "Lỗi kiểm tra tên đăng nhập: " + error.getMessage(), Toast.LENGTH_LONG).show();
                Log.e(TAG, "Database query cancelled: " + error.getMessage());
            }
        });
    }
}