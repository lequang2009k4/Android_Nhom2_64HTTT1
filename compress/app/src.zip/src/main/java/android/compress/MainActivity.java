package android.compress; // Thay đổi thành tên gói của bạn

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent; // Thêm import này
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = findViewById(R.id.startButton);
        if (startButton != null) {
            startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Chuyển sang LoginActivity
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    // Nếu bạn không muốn quay lại MainActivity sau khi login, có thể dùng finish();
                    // finish();
                }
            });
        }
    }
}